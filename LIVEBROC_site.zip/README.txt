# LIVEBROC
Prototype web de plateforme de vente en direct.

## Utilisation
Ouvre `index.html` dans Chrome, Edge ou Firefox.
Le prototype fonctionne sans serveur : recherche, filtres, ouverture d'un live, chat local, connexion et formulaire de lancement de live sont simulés.

## Pour une vraie plateforme
Il faudra ensuite connecter :
- comptes utilisateurs
- base de données
- vidéos live
- paiement sécurisé
- commandes/livraison
- modération
- notifications
